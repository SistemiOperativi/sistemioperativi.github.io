/*********************************************************************
 *  _____  ______          _____  __  __ ______ 
 * |  __ \|  ____|   /\   |  __ \|  \/  |  ____|
 * | |__) | |__     /  \  | |  | | \  / | |__   
 * |  _  /|  __|   / /\ \ | |  | | |\/| |  __|  
 * | | \ \| |____ / ____ \| |__| | |  | | |____ 
 * |_|  \_\______/_/    \_\_____/|_|  |_|______|
 * 
 * *******************************************************************
 * 
 * 
 * DO NOT FORGET TO FILL THE FOLLOWING WITH YOUR PERSONAL DATA
 * First Name:
 * Last Name:
 * Student Id:
 * 
 * 
 * ***********************************/




/***************************************************************************************************
SPECIFICA (ITA):

Implementare una programma C che prende come argomento un intero N e un nome di file F.
- Il main thread crea:
  - un nuovo file F vuoto;
  - un array di N byte (unsigned char) inizializzati a 0;
  - N thread/processi Ti, con i in {1, 2, .., N}.

- Ciascun thread/processo legge una stringa Si da standard input.
- Ciascuna stringa Si è una sequenza di caratteri alfanumerici terminante per '\n'.

- I thread eseguono in mutua esclusione. In particolare, il thread Ti di turno:
  1. scrive su F il byte i-esimo dell'array condiviso se diverso da 0;
  2. sovrascrive il byte i-esimo dell'array con il primo byte o successivo dalla propria stringa Si;
  3. cede il turno al prossimo thread. 

- I turni sono assegnati secondo uno schema a priorità. Nello specifico il prossimo thread ad eseguire è il thread Ti tale che
  i è la posizione del byte con minimo valore nell'array condiviso. Nel caso di pareggio procede il thread Ti con i minore.

- Il programma termina non appena un thread ha scritto 5 volte sul file F


Esempio:

./exam 2 out.txt

array = { 0, 0}
T1 legge 'abdzwr'
T2 legge 'bbcqrs'

out.txt:
abbbcdqr

SPECS (ENG):

Implement a C program that takes an integer N and a file name F as arguments.
- The main thread creates:
  - a new empty file F;
  - an array of N bytes (unsigned char) initialized to 0;
  - N threads/processes Ti, where i is in {1, 2, ..., N}.

- Each thread/process reads a string Si from standard input.
- Each string Si is a sequence of alphanumeric characters terminated by '\n'.

- The threads execute with mutual exclusion. Specifically, the current turn thread Ti:
  1. writes the i-th byte of the shared array to file F if it is different from 0;
  2. overwrites the i-th byte of the array with the first or subsequent byte from its own string Si;
  3. yields the turn to the next thread.

- Turns are assigned based on a priority scheme. Specifically, the next thread to execute is the thread Ti such that
  i is the position of the byte with the minimum value in the shared array. In case of a tie, the thread Ti with the smaller i is chosen.

- The program terminates as soon as a thread has written 5 times to file F.

Example:

./exam 2 out.txt

array = {0, 0}
T1 reads 'abdzwr'
T2 reads 'bbcqrs'

out.txt:
abbbcdqr

****************************************************************************************************/


/*****************************
 * READY TO USE HEADERS
 *****************************/





#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <semaphore.h>


int main(int argc, char** argv) {
  

}

