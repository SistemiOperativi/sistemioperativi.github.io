/*********************************************************************
 *  _____  ______          _____  __  __ ______ 
 * |  __ \|  ____|   /\   |  __ \|  \/  |  ____|
 * | |__) | |__     /  \  | |  | | \  / | |__   
 * |  _  /|  __|   / /\ \ | |  | | |\/| |  __|  
 * | | \ \| |____ / ____ \| |__| | |  | | |____ 
 * |_|  \_\______/_/    \_\_____/|_|  |_|______|
 * 
 * *******************************************************************
 * 
 * 
 * DO NOT FORGET TO FILL THE FOLLOWING WITH YOUR PERSONAL DATA
 * First Name:
 * Last Name:
 * Student Id:
 * 
 * 
 * ***********************************/




/***************************************************************************************************
SPECIFICA (ITA):

Implementare una programma tale che prende come argomento un intero N e un nome di file F 
- Il main thread crea:
  - un nuovo file F vuoto
  - N thread/processi Ti, con i in {1, 2, .., N}
- ciascun thread/processo Ti legge una stringa Si da standard input senza alcun ordine preciso
- i thread scrivono su F il contenuto della stringa letta un carattere alla volta secondo uno schema round robin
- il programma termina quando ciascun thread/processo Ti ha scritto tutti i caratteri di Si

Esempio:

./exam 2 out.txt

T1 legge 'abcd'
T2 legge '1234'

out.txt:
a1b2c3d4

SPECS (ENG):

Implement a program such that it takes an integer N and a file name F as an argument
- The main thread creates:
  - a new empty file F
  - N threads/processes Ti, with i in {1, 2, .., N}
- each thread/process Ti reads a string Si from standard input in no precise order
- the threads write on F the content of the string one character at a time according to a round robin scheme
- the program terminates when each thread/process Ti has written all the characters for Si

Example:

./exam 2 out.txt

T1 reads 'abcd'
T2 reads '1234'


out.txt:
a1b2c3d4

****************************************************************************************************/


/***************************************************************************************************
 * Additional exercise:
 * make Ti access the standard input in a round robin fashion
 * make Ti access the file F in the reversed order they accessed the standard output
 *************************************************************************************************/


/*****************************
 * READY TO USE HEADERS
 *****************************/





#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <semaphore.h>


int main(int argc, char** argv) {


}

