/*********************************************************************
 *  _____  ______          _____  __  __ ______ 
 * |  __ \|  ____|   /\   |  __ \|  \/  |  ____|
 * | |__) | |__     /  \  | |  | | \  / | |__   
 * |  _  /|  __|   / /\ \ | |  | | |\/| |  __|  
 * | | \ \| |____ / ____ \| |__| | |  | | |____ 
 * |_|  \_\______/_/    \_\_____/|_|  |_|______|
 * 
 * *******************************************************************
 * 
 * 
 * DO NOT FORGET TO FILL THE FOLLOWING WITH YOUR PERSONAL DATA
 * First Name:
 * Last Name:
 * Student Id:
 * 
 * 
 * ***********************************/




/***************************************************************************************************
SPECIFICA (ITA):

Implementare una programma tale che prende come argomento N nomi di file F1, F2, .. Fn 
- Il main thread crea N thread/processi Ti, con i in {1, 2, .., n}
- il main thread ripetutamente:
  1. legge da standard input una stringa S (senza alcuno spazio bianco)
  2. ridereziona S ad un thread/processo child senza alcun ordine prestabilito
  3. torna ad 1.
- ciascun thread/process Ti
  - crea un nuovo file vuoto Fi
  - per ciascuna stringa S ricevuta, scrive S sul Fi
- quando il main thread legge la stringa 'quit':
  - comunica a ciascun thread/processo di terminare
  - termina la sua esecuzione

SPECS (ENG):

Implement a program such that it takes N filenames F1, F2, .. Fn as arguments
- The main thread creates N threads/processes Ti, with i in {1, 2, .., n}
- the main thread repeatedly:
  1. reads a string S from standard input (without any white space)
  2. redirect S to a child thread/process without any pre-established order
  3. back to 1.
- each thread/process Ti
  - create a new empty file Fi
  - for each received string S, write S on Fi
- when the main thread reads the string 'quit':
  - tells each thread/process to terminate
  - ends its execution




****************************************************************************************************/


/***********************
 * Additional exercise:
 * make T1 and T2 access the standard input in a strictly alternating manner (T1, T2, T1, T2 and so on)
 **********************/


/*****************************
 * READY TO USE HEADERS
 *****************************/





#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <semaphore.h>


int main(int argc, char** argv) {


}

