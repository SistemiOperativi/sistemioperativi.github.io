#include <stdio.h>

#ifndef ITERATIONS
#define ITERATIONS 5
#endif
void main(){
  int i;
  
  for(i=0;i<ITERATIONS;i++)
    printf("%d\n", i);
}
