#include <stdio.h>

int main()
{
    int var = -1;
    int *var_ptr = &var;

    printf("La variabile 'var' ha indirizzo %p e valore %d\n", &var, var);  // il numero di specificatori deve coincidere
    printf("La variabile 'var_ptr' ha indirizzo %p e valore %p. "           // con il numero di parametri aggiuntivi
        "Il contenuto all'indirizzo referenziato è %d\n", &var_ptr, var_ptr, *var_ptr); 
    
    printf("Taglia di un int     %ld\n", sizeof(var)); // la 'l' prima di 'd' specifica la lunghezza del parametro
    printf("Decimale con segno   %d\n", var);   // interpreta l'intero come decimale con segno
    printf("Decimale unsigned    %u\n", var);   // interpreta l'intero come decimale unsigned
    printf("Intero ottale        %o\n", var);   // interpreta l'intero come ottale unsigned
    printf("Intero esadecimale   %x\n", var);   // interpreta l'intero come esadecimale unsigned

    printf("Valore decimale con segno %d\n", -1);           

    // la U dopo la costante numerica indica che è un unsigned
    printf("Valore decimale con segno %d\n", 4294967295U);  
    // il prefisso '0' indica che la costante a seguire è espressa in codifica ottale
    printf("Valore decimale con segno %d\n", 037777777777); 
    // il prefisso '0x' indica che la costante a seguire è espressa in codifica esadecimale
    printf("Valore decimale con segno %d\n", 0xffffffff); 
    return 0;
}