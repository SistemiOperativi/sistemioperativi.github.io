#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

int main()
{
    int buff_size = 0;
    char *dyn_buff;

    scanf("%ms %*s", &dyn_buff);
    // perche' usare il post incremento?
    while (dyn_buff[buff_size++] != '\0');
    
    printf("\nStringa inserita nel buffer allocato dinamicamente:  '%s'\n", dyn_buff);
    printf("\nTaglia del buffer allocato dinamicamente:  richiesta %d vs disponibile %ld\n",
     buff_size, malloc_usable_size(dyn_buff));

    char stk_buff[buff_size];
    int i;

    for (i=0; i<buff_size; i++) stk_buff[i] = dyn_buff[i];

    free(dyn_buff);

    printf("\nStringa copiata nel buffer allocato sullo stack:  '%s'\n\n", stk_buff);
}