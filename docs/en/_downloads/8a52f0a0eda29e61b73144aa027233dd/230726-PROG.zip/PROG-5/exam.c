/*********************************************************************
 *  _____  ______          _____  __  __ ______ 
 * |  __ \|  ____|   /\   |  __ \|  \/  |  ____|
 * | |__) | |__     /  \  | |  | | \  / | |__   
 * |  _  /|  __|   / /\ \ | |  | | |\/| |  __|  
 * | | \ \| |____ / ____ \| |__| | |  | | |____ 
 * |_|  \_\______/_/    \_\_____/|_|  |_|______|
 * 
 * *******************************************************************
 * 
 * 
 * DO NOT FORGET TO FILL THE FOLLOWING WITH YOUR PERSONAL DATA
 * First Name:
 * Last Name:
 * Student Id:
 * 
 * 
 * ***********************************/




/***************************************************************************************************
SPECIFICA (ITA):

Implementare una programma C che prende come argomento un intero N (al più pari a 25) e un nome di file F.
- Il main thread crea:
  - un nuovo file F vuoto;
  - N thread/processi Ti, con i in {1, 2, .., N}.

- I thread in ordine da T1 a Tn leggono 50 byte da standard input.
- Ciascuna Ti accumula in un singolo byte il valore di ciascun byte letto tramite l'operatore di somma 
  ottenendo un numero Ki compreso tra -128 e 127
- I thread scrivono su F il numero ottenuto come stringa (si consiglia l'uso di dprintf/fprintf) secondo l'ordine
  crescente dato dai Ki

- Il programma termina quando tutti i thread hanno scritto su file



****************************************************************************************************/


/*****************************
 * READY TO USE HEADERS
 *****************************/





#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <semaphore.h>

#define abort(x) do{printf(x"\n"); exit(1);}while(0)

typedef struct __th_data_t{
  sem_t *sems;
  char* shared_out;
  char* shared_dne;
  char* shared_cnt;
  int id;
  int n_th;
  int fd;
}th_data_t;


void schedule(th_data_t *data){
  int j=data->n_th+1;
  char val= 127;
  for(int i=0;i<data->n_th;i++){
    if(data->shared_dne[i] == 0 && (
        data->shared_out[i] < val || (i < j && data->shared_out[i] == val )
        ) 
      ){
      val = data->shared_out[i];
      j = i;
    }
  }
  sem_post(data->sems+j+1);
}


void *th_func(void *args){
  th_data_t *data = (th_data_t*) args;
  char buf[50];
  int res = read(0, buf, 50);
  char acc = 0;

  if(res!=50) abort("failed read");
  
  for(int i=0; i<50;i++) acc+=buf[i];

  sem_wait(data->sems);
    data->shared_out[data->id]  = acc;
    *data->shared_cnt = *data->shared_cnt +1;
    if(*data->shared_cnt == data->n_th) schedule(data);
  sem_post(data->sems);
  
  sem_wait(data->sems+1+data->id);
  dprintf(data->fd, "%d ", acc);
  data->shared_dne[data->id] = 1;
  schedule(data);
  sem_destroy(data->sems+1+data->id);
}

int main(int argc, char** argv) {
  if(argc != 3) abort("missing parameters");

  int n_th = atoi(argv[1]);
  char* outfile = argv[2];

  if(n_th <= 0 || n_th > 25) abort("wrong num of threads");

  int fd = open(outfile, O_CREAT | O_TRUNC | O_WRONLY, 660);
  if(fd<0) abort("cannot create file");

  th_data_t *data   = malloc(sizeof(th_data_t)*n_th);
  char *shared_out  = malloc(n_th);
  char *shared_dne  = malloc(n_th);
  char *shared_cnt  = malloc(1);
  pthread_t *tids   = malloc(sizeof(pthread_t)*n_th);
  sem_t *gl_sems    = malloc(sizeof(sem_t)*(n_th+1));


  *shared_cnt=0;
  sem_init(gl_sems, PTHREAD_PROCESS_PRIVATE, 1);

  for(int i=0;i<n_th;i++){
    data[i].n_th = n_th;
    data[i].fd = fd;
    data[i].shared_out = shared_out;
    data[i].shared_dne = shared_dne;
    data[i].shared_cnt = shared_cnt;
    data[i].sems = gl_sems;
    data[i].id = i;
    sem_init(gl_sems+i+1, PTHREAD_PROCESS_PRIVATE, 0);
    pthread_create(&tids[i], NULL, th_func, data+i);
  }


  for(int i=0;i<n_th;i++) pthread_join(tids[i], NULL);

  dprintf(data->fd, "\n");
  close(fd);

  free(data);
  free(shared_out);
  free(shared_dne);
  free(shared_cnt);
  free(tids);
  free(gl_sems);

}

